<?php
  
  $conexao = '';
  $server = "localhost";    
  $user = "root";           
  $pass = "";              
  $db = "wikisports";      
  $conexao = mysqli_connect($server,$user,$pass,$db); 
  
  mysqli_set_charset($conexao,"utf8"); 

  
  $sql = "SELECT cod_esporte, nome_esporte, descricao_esporte FROM esportes "; 
  $resultado = mysqli_query($conexao, $sql); 
?>

<!DOCTYPE html>

<html>
    <head>
        <title>WikiSports</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/estilo.css" type="text/css" media="all">
        <script src="js/jsnativo.js"></script>
    </head>

    <body onload="atualizaHora()">
       
        <header>
            <a href="index.html">
                <img id="logo" src="img\logo_wikisports.png" alt="WikiSports">
            </a>
        </header>

        <form id="faleconosco" name="faleconosco" method="POST" action="livia.martins@aluno.ifsp.edu.br">
            <h2>Quer saber mais? Quer contribuir? Escreva-nos!</h2>
            <fieldset name="dadospessoais" form="faleconosco">
                <legend>Dados Pessoais</legend>
                <p><input type="text" id="datahora" name="hoje" size="50" disabled/></p>
                
                <p><label>Nome: </label> 
                <input type="text" id="nome" name="nome" maxlength="50" size="60" required/></p>

                <p><label>e-mail: </label>
                <input type="email" id="email" name="email" maxlength="50" size="60" autocomplete="on" required/></p>
                
                <p><label>Telefone: </label>
                <input type="tel" id="telefone" name="telefone" maxlength="13" size="12"/></p>
                
                <p><label>Idade: </label> <input type="text" id="idade" name="idade" maxlength="3" size="3"/></p>
                
                <p>
                    <label>Gênero: </label> 
                    <label for="m">M</label> <input type="radio" id="m" name="genero" value="m" required/>
                    <label for="f">F</label> <input type="radio" id="f" name="genero" value="f" required/>
                </p>
            </fieldset>
            
            <fieldset name="comentarios" form="faleconosco">
                <legend>Comentários</legend>
                    <p>
                        <label>Indique quanto esse portal agradou: </label> 
                        <input type="number" id="quantidade" name="quantidade" min=0 max=10 size=5 onClick="preencheBarra()"/>    
                        <meter id="medidor1" name="medidor1" value=8 min=0 max=10>8 de 10</meter>
                    </p>
        
                    <p>
                        <label>Qual seu esporte preferido? </label> 
                        <select id="idEsporte" required>
                            <option value="">Escolha uma opção...</option>
                          
                            <?php if(isset($resultado)){
                                    while($reg = mysqli_fetch_assoc($resultado)){ 
                                        $nomeEsporte = $reg['nome_esporte'];
                                        $codEsporte = $reg['cod_esporte']; ?>
                                    <option value="<?php echo $codEsporte; ?>"><?php echo $nomeEsporte; ?></option>
                                    <?php } ?>
                            <?php } ?>
                        </select>                  
                    </p> 
                    
                <p>
                    <label>Deixe aqui seus comentários: </label> 
                    <textarea id="opiniao" name="comentario" cols=60 rows=10 maxlength="500" spellcheck="true"></textarea>
                </p>
            </fieldset>
            
            <div id="botoes">
                <input type="submit" id="enviar" value="Enviar" onClick="consiste()"/>
                <input type="reset" id="limpar" value="Limpar"/>
            </div>
        </form>

        <footer>
            <br><br>
            <p>
                Copyright &copy; 2022 - All Rights Reserved - <a href="index.html">WikiSports</a><br>
                Página desenvolvida por Lívia Martins e Allanis na disciplina DSW do curso CTII no IFSP<br>
                Instituto Federal de Educação Ciência e Tecnologia de São Paulo - Campus Cubatão
            </p>
        </footer>
        
    </body>
        
    </body>
</html>
